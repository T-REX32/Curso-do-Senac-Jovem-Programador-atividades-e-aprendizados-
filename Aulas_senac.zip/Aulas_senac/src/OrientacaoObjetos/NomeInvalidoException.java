package OrientacaoObjetos;

public class NomeInvalidoException extends Exception {
	public NomeInvalidoException(String mensagem) {
		super(mensagem);
	}
}